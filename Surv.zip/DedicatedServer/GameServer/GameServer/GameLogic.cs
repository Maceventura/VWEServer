﻿using System;


namespace GameServer
{
	public class GameLogic
	{
		public static void Update()
		{
			ThreadManager.UpdateMain();
		}
	}
}
